Drag And Drop All Files To
Windows: %Appdata%/.minecraft
Mac:/Users/<User>/Library/Application Support/minecraft
Linux: ~/.minecraft
